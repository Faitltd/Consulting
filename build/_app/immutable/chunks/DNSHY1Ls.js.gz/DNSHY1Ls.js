import{H as e}from"./CYgJF_JY.js";function n(r,o){throw new e(r,o)}new TextEncoder;export{n as e};
