import"./NZTpNUN0.js";import"./BCHcx9qG.js";import{h as l,a as N,i as y,ay as R,b as D,E as F,g as I,az as O,A as q,C as G,aw as L,e as C,s as $,aj as Q,p as V,f as H,aA as J,ae as K,aB as U,l as E,af as X,R as Y,q as S,w as g,S as Z,Q as ee,j as W,k as T,v as b,aC as te,aD as ae}from"./DSpJZVee.js";import{l as x,p as m,s as se}from"./hPbPQDID.js";import{a as z,e as re,i as ne}from"./c5NWnUeM.js";import{i as oe}from"./DTAtkvOO.js";import{i as ie}from"./D2i1s2UK.js";function j(c,e,d,o,u){l&&N();var f=e.$$slots?.[d],a=!1;f===!0&&(f=e.children,a=!0),f===void 0||f(c,a?()=>o:o)}function le(c,e,d,o,u,f){let a=l;l&&N();var n,_,t=null;l&&y.nodeType===R&&(t=y,N());var v=l?y:c,s;D(()=>{const r=e()||null;var k=O;r!==n&&(s&&(r===null?V(s,()=>{s=null,_=null}):r===_?H(s):J(s)),r&&r!==_&&(s=I(()=>{if(t=l?t:document.createElementNS(k,r),q(t,t),o){l&&oe(r)&&t.append(document.createComment(""));var i=l?G(t):t.appendChild(L());l&&(i===null?C(!1):$(i)),o(t,i)}Q.nodes_end=t,v.before(t)})),n=r,n&&(_=n))},F),a&&(C(!0),$(v))}/**
 * @license lucide-svelte v0.555.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const de={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var fe=U("<svg><!><!></svg>");function ce(c,e){const d=x(e,["children","$$slots","$$events","$$legacy"]),o=x(d,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);K(e,!1);let u=m(e,"name",8,void 0),f=m(e,"color",8,"currentColor"),a=m(e,"size",8,24),n=m(e,"strokeWidth",8,2),_=m(e,"absoluteStrokeWidth",8,!1),t=m(e,"iconNode",24,()=>[]);const v=(...i)=>i.filter((h,p,w)=>!!h&&w.indexOf(h)===p).join(" ");ie();var s=fe();z(s,(i,h)=>({...de,...o,width:a(),height:a(),stroke:f(),"stroke-width":i,class:h}),[()=>(g(_()),g(n()),g(a()),S(()=>_()?Number(n())*24/Number(a()):n())),()=>(g(u()),g(d),S(()=>v("lucide-icon","lucide",u()?`lucide-${u()}`:"",d.class)))]);var r=Y(s);re(r,1,t,ne,(i,h)=>{var p=te(()=>ae(b(h),2));let w=()=>b(p)[0],M=()=>b(p)[1];var A=W(),P=T(A);le(P,w,!0,(B,ue)=>{z(B,()=>({...M()}))}),E(i,A)});var k=Z(r);j(k,e,"default",{}),ee(s),E(c,s),X()}function we(c,e){const d=x(e,["children","$$slots","$$events","$$legacy"]),o=[["path",{d:"M7 7h10v10"}],["path",{d:"M7 17 17 7"}]];ce(c,se({name:"arrow-up-right"},()=>d,{get iconNode(){return o},children:(u,f)=>{var a=W(),n=T(a);j(n,e,"default",{}),E(u,a)},$$slots:{default:!0}}))}export{we as A,ce as I,j as s};
