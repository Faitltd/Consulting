const e="5";typeof window<"u"&&((window.__svelte??={}).v??=new Set).add(e);
